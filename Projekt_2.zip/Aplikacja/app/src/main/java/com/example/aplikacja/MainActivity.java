package com.example.aplikacja;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    TextView questionText, scoreText;
    Button startButton, resetButton, answerA, answerB, answerC;

    ArrayList<Question> allQuestions = new ArrayList<>();
    ArrayList<Question> quizQuestions = new ArrayList<>();

    int index = 0;
    int score = 0;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionText = findViewById(R.id.questionText);
        scoreText = findViewById(R.id.scoreText);
        startButton = findViewById(R.id.startButton);
        resetButton = findViewById(R.id.resetButton);
        answerA = findViewById(R.id.answerA);
        answerB = findViewById(R.id.answerB);
        answerC = findViewById(R.id.answerC);

        loadQuestions();
        showStart();

        startButton.setOnClickListener(v -> startQuiz());
        resetButton.setOnClickListener(v -> showStart());

        answerA.setOnClickListener(v -> check(answerA.getText().toString()));
        answerB.setOnClickListener(v -> check(answerB.getText().toString()));
        answerC.setOnClickListener(v -> check(answerC.getText().toString()));
    }

    void loadQuestions() {
        allQuestions.add(new Question("Stolica Polski?", "Warszawa", "Berlin", "Praga", "Warszawa"));
        allQuestions.add(new Question("2+2?", "3", "4", "5", "4"));
        allQuestions.add(new Question("Kolor nieba?", "Niebieski", "Zielony", "Czarny", "Niebieski"));
        allQuestions.add(new Question("5x3?", "15", "10", "8", "15"));
        allQuestions.add(new Question("Stolica Włoch?", "Rzym", "Paryż", "Madryt", "Rzym"));
        allQuestions.add(new Question("Kot robi?", "Miau", "Hau", "Bee", "Miau"));
    }

    void showStart() {
        score = 0;
        index = 0;

        questionText.setVisibility(View.GONE);
        answerA.setVisibility(View.GONE);
        answerB.setVisibility(View.GONE);
        answerC.setVisibility(View.GONE);

        startButton.setVisibility(View.VISIBLE);
        scoreText.setText("Wynik: 0");
    }

    void startQuiz() {
        Collections.shuffle(allQuestions);
        quizQuestions.clear();

        for (int i = 0; i < 5; i++) {
            quizQuestions.add(allQuestions.get(i));
        }

        startButton.setVisibility(View.GONE);
        questionText.setVisibility(View.VISIBLE);
        answerA.setVisibility(View.VISIBLE);
        answerB.setVisibility(View.VISIBLE);
        answerC.setVisibility(View.VISIBLE);

        showQuestion();
    }

    void showQuestion() {
        Question q = quizQuestions.get(index);
        questionText.setText(q.question);
        answerA.setText(q.a);
        answerB.setText(q.b);
        answerC.setText(q.c);
    }

    void check(String ans) {
        if (ans.equals(quizQuestions.get(index).correct)) {
            score++;
            scoreText.setText("Wynik: " + score);
        }

        index++;

        if (index < 5) {
            showQuestion();
        } else {
            endQuiz();
        }
    }

    void endQuiz() {
        new AlertDialog.Builder(this)
                .setTitle("Koniec quizu!")
                .setMessage("Twój wynik: " + score + " / 5")
                .setPositiveButton("OK", null)
                .show();

        showStart();
    }
}